#include "thermo.h"
#include <stdlib.h>
#include <stdio.h>

// Uses the two global variables (ports) THERMO_SENSOR_PORT and
// THERMO_STATUS_PORT to set the temp structure. If THERMO_SENSOR_PORT
// is above its maximum trusted value, associated with +50.0 deg C,
// does not alter temp and returns 1.  Otherwise, sets fields of temp
// based on converting sensor value to degrees and checking whether
// Celsius or Fahrenheit display is in effect. Returns 0 on successful
// set. This function DOES NOT modify any global variables but may
// access global variables.
//
// CONSTRAINT: Uses only integer operations. No floating point
// operations are used as the target machine does not have a FPU.

int set_temp_from_ports(temp_t *temp){
    if(THERMO_SENSOR_PORT > 64000){
        return 1;
    }
    temp->tenths_degrees = (THERMO_SENSOR_PORT/64) - 500;
    if(THERMO_SENSOR_PORT%64 >= 32){
        temp->tenths_degrees++;
    }
    temp->is_fahrenheit = 0;
    int mask = THERMO_STATUS_PORT;
    if((mask&0b00000001) == 1){
        temp->tenths_degrees = (temp->tenths_degrees*9)/5 + 320;
        temp->is_fahrenheit = 1;
    }
    return 0;
}

// Alters the bits of integer pointed to by display to reflect the
// temperature in struct arg temp.  If temp has a temperature value
// that is below minimum or above maximum temperature allowable or if
// an improper indication of celsius/fahrenheit is given, does nothing
// and returns 1. Otherwise, calculates each digit of the temperature
// and changes bits at display to show the temperature according to
// the pattern for each digit.  This function DOES NOT modify any
// global variables but may access global variables.

int set_display_from_temp(temp_t temp, int *display){
    if(temp.is_fahrenheit == 1){ // Makes sure temp is in range for F
        if(temp.tenths_degrees > 1220 || temp.tenths_degrees < -580){
            return 1;
        }
    }
    else{
        if(temp.tenths_degrees > 500 || temp.tenths_degrees < -500){ // Makes sure temp is in range for C
            return 1;
        
        }
    }
    if(temp.is_fahrenheit != 0 && temp.is_fahrenheit != 1){ // Makes sure .is_fahrenheit is a readable value
        return 1;
    }
    *display = 0;
    int mask = 0;
    int mask_arr[10] = {0b1111110,0b0001100,0b0110111,0b0011111,0b1001101,0b1011011,0b1111011,0b0001110,0b1111111,0b1011111};
    int temp_hundreds = abs(temp.tenths_degrees/1000);
    int temp_tens = abs(temp.tenths_degrees/100)%10;
    int temp_ones = abs((temp.tenths_degrees%100)/10);
    int temp_tenths = abs(temp.tenths_degrees%10);
    if(temp.is_fahrenheit == 1){
        mask = mask | (0b10 << 28);
    } else{
        mask = mask | (0b01 << 28);
    }

    if(temp_hundreds == 0 && temp.tenths_degrees < 0 && temp_tens != 0){ // Checks if a negative needs to be inserted
        mask = mask | (0b0000001 << 21);
    }else if(temp_hundreds == 0){ // Checks if is leading 0 and change to blank space
        mask = mask | (0b0000000 << 21);
    }else{
        mask = mask | (mask_arr[temp_hundreds] << 21);
    }
    if(temp_tens == 0 && temp.tenths_degrees < 0){ // Checks if a negative needs to be inserted
        mask = mask | (0b0000001 << 14);
    }else if(temp_tens == 0 && temp_hundreds == 0){ // Checks if is leading 0 and change to blank space
        mask = mask | (0b0000000 << 14);
    }else{
        mask = mask | (mask_arr[temp_tens] << 14);
    }
    mask = mask | (mask_arr[temp_ones] << 7);
    mask = mask | (mask_arr[temp_tenths]);
    *display = mask;

    return 0;
}


int thermo_update(){
    temp_t temp = {
      .tenths_degrees = 0,
      .is_fahrenheit  = 0,
    };
    set_temp_from_ports(&temp);
    set_display_from_temp(temp, &THERMO_DISPLAY_PORT);
    return 0;
}